// Code by Shubham Pardeshi & Atharva Ranade
#include <iostream>
#include <string>
#include "ppm.h"

ppm::ppm(int magicNo, int height, int width, int max_val, vector<colorPixel> pixels){
    this->magicNumber = magicNo;
    this->height = height;
    this->width = width;
    this->max_val = max_val;
    this->Pixel = pixels;
}