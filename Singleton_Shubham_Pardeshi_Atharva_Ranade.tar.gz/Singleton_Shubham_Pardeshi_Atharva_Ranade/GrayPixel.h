// Code by Shubham Pardeshi & Atharva Ranade

#include <iostream>
#include <string>

using namespace std;

class grayPixel
{
private:
    unsigned char gray;
public:
    grayPixel(){}
    grayPixel(unsigned char gray);

unsigned getGray(){return gray;};

void setGray(unsigned char grey) { this->gray = gray; };
~grayPixel() {}
};
