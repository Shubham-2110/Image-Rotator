// Code by Shubham Pardeshi & Atharva Ranade
#include <iostream>
#include <string>
#include "pgm.h"

pgm::pgm(int magicNumber, int height, int width, int max_val, vector<grayPixel> grpixel)
{
    this->getgrayMagic();
    this->getgrayHeight();
    this->getgrayWidth();
    this->getgraymaxVal();
    this->getgrayPixel();
}