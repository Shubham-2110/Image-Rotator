// Code by Shubham Pardeshi & Atharva Ranade

#include <iostream>
#include <string>

using namespace std;

class colorPixel{

private:
unsigned char red_color;
unsigned char green_color;
unsigned char blue_color;

public:

colorPixel(){}
colorPixel(unsigned char red_color, unsigned char green_color, unsigned char blue_color);

unsigned char getRed(){return red_color;}
unsigned char getGreen(){return green_color;}
unsigned char getBlue(){return blue_color;}

void setRed(unsigned char red) { this->red_color = red; }
void setGreen(unsigned char green) { this->green_color = green; }
void setBlue(unsigned char blue) { this->blue_color = blue; }

~colorPixel() {}
};
