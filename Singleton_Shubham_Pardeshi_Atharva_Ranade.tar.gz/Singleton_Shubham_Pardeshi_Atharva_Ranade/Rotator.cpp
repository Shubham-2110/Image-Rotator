// Code by Shubham Pardeshi & Atharva Ranade

#include <iostream>
#include <fstream>
#include <string>
#include "Rotator.h"
using namespace std;

void PpmRead(ppm* ppm, const string& input_file);
void PpmWrite(ppm* ppm, const string& input_file);

bool PgmRead(pgm* pgm, const string& input_file);
void PgmWrite(pgm* pgm, const string& input_file);
Rotator *Rotator::instance = 0;
int main(int argc, const char* argv[]) {
    string input_file = argv[1];
    string output_file = argv[2];
    int rotate_deg = 0;
    string fileType = input_file.substr(input_file.length() - 3, 3);

    Rotator *rotator = rotator->getInstance();
    ppm* ppm1 = new ppm();
    ppm* rotatedppm = new ppm();
    rotator->Rotate(ppm1, rotatedppm, rotate_deg);
    PpmWrite(rotatedppm, output_file);
    if(rotate_deg == 180 && fileType == "ppm"){
        void Rotate(ppm * inputppm, ppm * outppm, int rotate_deg);
        void Rotate(ppm * inputppm, ppm * outppm, int rotate_deg);
    }
    else if (rotate_deg == 270 && fileType == "ppm"){
        void Rotate(ppm * inputppm, ppm * outppm, int rotate_deg);
        void Rotate(ppm * inputppm, ppm * outppm, int rotate_deg);
        void Rotate(ppm * inputppm, ppm * outppm, int rotate_deg);
    }

    if (rotate_deg == 180 && fileType == "pgm"){
        void Rotate(pgm * inputppm, pgm * outppm, int rotate_deg);
        void Rotate(pgm * inputppm, pgm * outppm, int rotate_deg);
    }
    else if (rotate_deg == 270 && fileType == "pgm"){
        void Rotate(pgm * inputppm, pgm * outppm, int rotate_deg);
        void Rotate(pgm * inputppm, pgm * outppm, int rotate_deg);
        void Rotate(pgm * inputppm, pgm * outppm, int rotate_deg);
    }else if (rotate_deg > 270){
      cout << "not a valid input (only 90 180 270 allowed)" << endl;
    }
    return 0;
}
void PpmRead(ppm* ppm, const string& input_file){
    ifstream file(input_file.c_str(), ios::in | ios::binary);
    int magicNumber, height, width, maxVal;
    vector<colorPixel> pixel = ppm->getPixel();
    pixel.resize(height * width);
    if (magicNumber == 6){
        for (int i = 0; i < pixel.size(); i++){
            char red,green,blue;
            file.get(red);
            file.get(green);
            file.get(blue);
            pixel[i].setRed(red);
            pixel[i].setGreen(green);
            pixel[i].setBlue(blue);
        }
    }
    else if (magicNumber == 3){
        for (int i = 0; i < pixel.size(); i++){
            char r, g, b;
            file >> r;
            file >> g;
            file >> b;
            pixel[i].setRed(r);
            pixel[i].setGreen(g);
            pixel[i].setBlue(b);
        }
    }
    ppm->setmagicNo(magicNumber);
    ppm->setHeight(height);
    ppm->setWidth(width);
    ppm->setMaxVal(maxVal);
    ppm->setPixel(pixel);
    file.close();
}
void PpmWrite(ppm* ppm, const string& input_file){
    ofstream file1;
    file1.open(input_file);
    file1 << "P" << ppm->getMagic() <<endl;
    file1 << ppm->getHeight() << endl;
    file1 << ppm->getWidth() << endl;
    file1 << ppm->getmaxVal() << endl;
    for (colorPixel pixel : ppm->getPixel()){
        if (ppm->getMagic() == 6){
            file1 << pixel.getRed() << pixel.getGreen() << pixel.getBlue();
        }
        else{
            file1 << pixel.getRed() << endl;
            file1 << pixel.getGreen() << endl;
            file1 << pixel.getBlue() << endl;
        }
    }
    file1.close();
}
bool PgmRead(pgm* pgm, const string& input_file){
    ifstream file(input_file.c_str(), ios::in | ios::binary);
    int magicNumber, height, width, maxVal;
    vector<grayPixel> pixel = pgm->getgrayPixel();
    pixel.resize(height * width);
    if (magicNumber == 5){
        for (int i = 0; i < pixel.size(); i++){
            char gray;
            file.get(gray);
            pixel[i].setGray(gray);
        }
    }
    else if (magicNumber == 2){
        for (int i = 0; i < pixel.size(); i++){
            char gr;
            file >> gr;
            pixel[i].setGray(gr);
        }
    }
    pgm->setmagicNo(magicNumber);
    pgm->setHeight(height);
    pgm->setWidth(width);
    pgm->setMaxVal(maxVal);
    pgm->setPixel(pixel);
    file.close();
    return true;
}
void PgmWrite(pgm* pgm, const string& input_file){
    ofstream file;
    file.open(input_file);
    file << "P" << pgm->getgrayMagic() << endl;
    file << pgm->getgrayHeight() << endl;
    file << pgm->getgrayWidth() << endl;
    file << pgm->getgraymaxVal() << endl;
    for (grayPixel pixel : pgm->getgrayPixel()){
        if (pgm->getgrayMagic() == 5)
        {
            file << pixel.getGray();
        }
        else
        {
            file << pixel.getGray() << endl;
        }
    }
    file.close();
}
