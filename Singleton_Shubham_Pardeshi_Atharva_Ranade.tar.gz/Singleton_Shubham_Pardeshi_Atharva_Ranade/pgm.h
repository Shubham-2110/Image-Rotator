// Code by Shubham Pardeshi & Atharva Ranade
#include <iostream>
#include <string>
#include <vector>
#include "GrayPixel.h"

using namespace std;

class pgm
{
private:
    int magicNumber, height, width, max_val;
    vector<grayPixel> graypixel;

public:
    pgm(){}
    pgm(int magicNo, int height, int width, int max_val, vector<grayPixel> grpixels);

    int getgrayMagic() { return magicNumber; };
    int getgrayHeight() { return height; };
    int getgrayWidth() { return width; };
    int getgraymaxVal() { return max_val; };
    vector<grayPixel> getgrayPixel() { return graypixel; };

    void setmagicNo(int magicNo) { this->magicNumber = magicNo; };
    void setHeight(int height) { this->height = height; };
    void setWidth(int width) { this->width = width; };
    void setMaxVal(int max_val) { this->max_val = max_val; };
    void setPixel(vector<grayPixel>) { this->graypixel = graypixel; };

    ~pgm() {}
};


