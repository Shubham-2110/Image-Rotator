// Code by Shubham Pardeshi & Atharva Ranade
#include <vector>
#include "ppm.h"
#include "pgm.h"

class Rotator
{
private:
    static Rotator *instance;

    Rotator(){};

public:
    static Rotator *getInstance()
    {
        if (!instance)
            instance = new Rotator();
        return instance;
    };
    
    
    void Rotate(ppm *inputppm, ppm *outputppm, int rotate_deg);
    void Rotate(pgm *inputpgm, pgm *outputpgm, int rotate_deg);
};

void Rotator::Rotate(ppm *input, ppm *output, int rotate_deg)
{

    int magicNum = input->getMagic();
    int maxVal = input->getmaxVal();
    int input_Width = input->getWidth();
    int input_Height = input->getHeight();
    std::vector<colorPixel> input_Pixels = input->getPixel();

    std::vector<colorPixel> output_Pixels(input_Pixels.size());

    if (rotate_deg == 90)
    {
        for (int y = 0; y < input_Height; y++)
        {
            for (int x = 0; x < input_Width; x++)
            {
                output_Pixels[(x * input_Height) + (input_Height - y - 1)] =
                    input_Pixels[(y * input_Width) + x];
            }
        }

        output->setmagicNo(magicNum);
        output->setMaxVal(maxVal);
        output->setWidth(input_Height);
        output->setHeight(input_Width);
        output->setPixel(output_Pixels);
    }
}
void Rotator::Rotate(pgm *input, pgm *output, int rotate_deg)
{

    int magicNo = input->getgrayMagic();
    int maxVal = input->getgraymaxVal();
    int inputWidth = input->getgrayWidth();
    int inputHeight = input->getgrayHeight();
    std::vector<grayPixel> input_Pixels = input->getgrayPixel();

    std::vector<grayPixel> output_Pixels(input_Pixels.size());

    if (rotate_deg == 90){
        for (int y = 0; y < inputHeight; y++)
        {
            for (int x = 0; x < inputWidth; x++)
            {
                output_Pixels[(x * inputHeight) + (inputHeight - y - 1)] =
                    input_Pixels[(y * inputWidth) + x];
            }
        }
        output->setmagicNo(magicNo);
        output->setMaxVal(maxVal);
        output->setWidth(inputHeight);
        output->setHeight(inputWidth);
        output->setPixel(output_Pixels);
    }    
}