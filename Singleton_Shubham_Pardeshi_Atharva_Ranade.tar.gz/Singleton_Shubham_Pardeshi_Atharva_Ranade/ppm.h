// Code by Shubham Pardeshi & Atharva Ranade
#include <iostream>
#include <string>
#include <vector>
#include "ColorPixel.h"

using namespace std;

class ppm
{
public:
    int magicNumber, height, width, max_val;
    vector<colorPixel> Pixel;
public:
    ppm(){}
    ppm(int magicNumber, int height, int width, int max_val, vector<colorPixel> pixels);
    

    int getMagic(){  return magicNumber; };
    int getHeight() { return height;};
    int getWidth() { return width; };
    int getmaxVal(){ return max_val; }; 
    vector<colorPixel> getPixel(){ return Pixel; };

    void setmagicNo(int magicNo) { this->magicNumber = magicNo; };
    void setHeight(int height) { this->height = height; };
    void setWidth(int width) { this->width = width; };
    void setMaxVal(int max_val) { this->max_val = max_val; };
    void setPixel(vector<colorPixel>) { this->Pixel = Pixel; };

    ~ppm(){}
};

